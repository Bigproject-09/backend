package com.example.agent_rnd.service;

import com.example.agent_rnd.client.FastApiClient;
import com.example.agent_rnd.domain.enums.ChecklistType;
import com.example.agent_rnd.domain.enums.ReferenceType;
import com.example.agent_rnd.domain.notice.ChecklistItem;
import com.example.agent_rnd.domain.notice.NoticeReference;
import com.example.agent_rnd.domain.notice.ProjectNotice;
import com.example.agent_rnd.repository.ChecklistItemRepository;
import com.example.agent_rnd.repository.NoticeReferenceRepository;
import com.example.agent_rnd.repository.ProjectNoticeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@RequiredArgsConstructor
@Transactional
public class NoticeAnalysisService {

    private final FastApiClient fastApiClient;

    private final ProjectNoticeRepository projectNoticeRepository;
    private final ChecklistItemRepository checklistItemRepository;
    private final NoticeReferenceRepository noticeReferenceRepository;

    // =========================
    // Step 1: 공고문 분석
    // =========================
    public Map<String, Object> runStep1(Long noticeId, Long companyId) {
        ProjectNotice notice = projectNoticeRepository.findById(noticeId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 noticeId=" + noticeId));

        Map<String, Object> fastapi = fastApiClient.analyzeNotice(noticeId, companyId);

        // 기존 체크리스트 삭제 후 재생성 (idempotent)
        checklistItemRepository.deleteByProjectNotice_NoticeId(noticeId);

        int saved = 0;

        Map<String, Object> data = asMap(fastapi.get("data"));
        Map<String, Object> checklist = asMap(data.get("checklist"));
        List<Map<String, Object>> judgments = asListOfMap(checklist.get("judgments"));

        for (Map<String, Object> j : judgments) {
            String category = asString(j.get("category"));
            String requirementText = asString(j.get("requirement_text"));
            String judgment = asString(j.get("judgment"));

            if (requirementText.isBlank()) continue;

            ChecklistType type = mapChecklistType(category, requirementText);

            String content = ("[" + judgment + "] " + requirementText).trim();
            if (content.length() > 500) {
                content = content.substring(0, 497) + "...";
            }

            ChecklistItem.of(notice, type, content);
            saved++;
        }

        projectNoticeRepository.save(notice); // cascade로 checklists 저장

        return Map.of(
                "status", "success",
                "noticeId", noticeId,
                "savedChecklistCount", saved,
                "fastapi", fastapi
        );
    }

    // =========================
    // Step 2: 유관 RFP 검색
    // =========================
    public Map<String, Object> runStep2(Long noticeId, Long companyId) {
        ProjectNotice notice = projectNoticeRepository.findById(noticeId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 noticeId=" + noticeId));

        Map<String, Object> fastapi = fastApiClient.searchSimilarRfp(noticeId);

        // 기존 LINK 타입 참고자료 삭제 후 재생성
        noticeReferenceRepository.deleteByProjectNotice_NoticeIdAndType(noticeId, ReferenceType.LINK);

        List<NoticeReference> refs = new ArrayList<>();
        extractUrlTitlePairs(fastapi).stream()
                .limit(30)
                .forEach(p -> refs.add(NoticeReference.of(notice, ReferenceType.LINK, p.title, p.url)));

        noticeReferenceRepository.saveAll(refs);

        return Map.of(
                "status", "success",
                "noticeId", noticeId,
                "savedReferenceCount", refs.size(),
                "fastapi", fastapi
        );
    }

    // =========================
    // Step 3: PPT 생성
    // =========================
    public Map<String, Object> runStep3(Long noticeId, Long companyId) {
        ProjectNotice notice = projectNoticeRepository.findById(noticeId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 noticeId=" + noticeId));

        Map<String, Object> fastapi = fastApiClient.generatePpt(noticeId);

        // FILE 타입 참고자료는 step3/4에서 같이 사용하므로, title로 구분해서 덮어씀
        String pptPath = null;
        Integer slidesCount = null;

        Map<String, Object> data = asMap(fastapi.get("data"));
        pptPath = asString(data.get("ppt_path"));
        slidesCount = asInt(data.get("slides_count"));

        // 기존 동일 제목 제거
        removeReferencesByTitle(noticeId, "Generated PPT");
        if (!pptPath.isBlank()) {
            NoticeReference ref = NoticeReference.of(
                    notice,
                    ReferenceType.FILE,
                    "Generated PPT",
                    pptPath
            );
            noticeReferenceRepository.save(ref);
        }

        return Map.of(
                "status", "success",
                "noticeId", noticeId,
                "pptPath", pptPath,
                "slidesCount", slidesCount,
                "fastapi", fastapi
        );
    }

    // =========================
    // Step 4: 스크립트 생성
    // =========================
    public Map<String, Object> runStep4(Long noticeId) {
        Map<String, Object> fastapi = fastApiClient.generateScript(noticeId);

        // fastapi 응답에 script_path 등이 포함되도록 FastAPI(main.py)도 같이 수정하는 것을 권장
        return Map.of(
                "status", "success",
                "fastapi", fastapi
        );
    }

    // =========================
    // 저장된 결과 조회 (프론트 결과 페이지용)
    // =========================
    @Transactional(readOnly = true)
    public Map<String, Object> getStored(Long noticeId) {
        List<ChecklistItem> checklists = checklistItemRepository.findByProjectNotice_NoticeId(noticeId);
        List<NoticeReference> refs = noticeReferenceRepository.findByProjectNotice_NoticeId(noticeId);

        List<Map<String, Object>> checklistView = new ArrayList<>();
        for (ChecklistItem c : checklists) {
            checklistView.add(Map.of(
                    "checklistId", c.getChecklistId(),
                    "type", c.getType().name(),
                    "content", c.getContent()
            ));
        }

        List<Map<String, Object>> refView = new ArrayList<>();
        for (NoticeReference r : refs) {
            refView.add(Map.of(
                    "referenceId", r.getReferenceId(),
                    "type", r.getType().name(),
                    "title", r.getTitle(),
                    "url", r.getUrl()
            ));
        }

        return Map.of(
                "noticeId", noticeId,
                "checklists", checklistView,
                "references", refView
        );
    }

    // =========================
    // helpers
    // =========================
    private ChecklistType mapChecklistType(String category, String requirementText) {
        String s = (category + " " + requirementText).toLowerCase(Locale.ROOT);
        if (s.contains("서류") || s.contains("제출") || s.contains("증빙")) return ChecklistType.DOCUMENT;
        if (s.contains("자격") || s.contains("대상") || s.contains("신청") || s.contains("기업")) return ChecklistType.QUALIFICATION;
        return ChecklistType.CONTENT;
    }

    private void removeReferencesByTitle(Long noticeId, String title) {
        List<NoticeReference> refs = noticeReferenceRepository.findByProjectNotice_NoticeId(noticeId);
        for (NoticeReference r : refs) {
            if (title.equals(r.getTitle())) {
                noticeReferenceRepository.delete(r);
            }
        }
    }

    private static Map<String, Object> asMap(Object o) {
        if (o instanceof Map<?, ?> m) {
            Map<String, Object> out = new LinkedHashMap<>();
            for (Map.Entry<?, ?> e : m.entrySet()) {
                out.put(String.valueOf(e.getKey()), e.getValue());
            }
            return out;
        }
        return new LinkedHashMap<>();
    }

    private static List<Map<String, Object>> asListOfMap(Object o) {
        if (!(o instanceof List<?> list)) return List.of();
        List<Map<String, Object>> out = new ArrayList<>();
        for (Object item : list) {
            out.add(asMap(item));
        }
        return out;
    }

    private static String asString(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    private static Integer asInt(Object o) {
        if (o == null) return null;
        try { return Integer.parseInt(String.valueOf(o)); } catch (Exception e) { return null; }
    }

    private record Pair(String title, String url) {}

    /**
     * FastAPI Step2 결과는 구조가 유동적이라서,
     * JSON 전체를 DFS로 훑어서 (title,url) 쌍을 최대한 뽑아낸다.
     */
    private static List<Pair> extractUrlTitlePairs(Object root) {
        List<Pair> pairs = new ArrayList<>();
        Deque<Object> stack = new ArrayDeque<>();
        stack.push(root);

        while (!stack.isEmpty()) {
            Object cur = stack.pop();
            if (cur instanceof Map<?, ?> m) {
                Object title = m.get("title");
                Object url = m.get("url");
                if (title != null && url != null) {
                    String t = String.valueOf(title).trim();
                    String u = String.valueOf(url).trim();
                    if (!t.isBlank() && !u.isBlank()) {
                        pairs.add(new Pair(t, u));
                    }
                }
                for (Object v : m.values()) stack.push(v);
            } else if (cur instanceof List<?> list) {
                for (Object v : list) stack.push(v);
            }
        }
        // 중복 제거(순서 유지)
        LinkedHashMap<String, Pair> uniq = new LinkedHashMap<>();
        for (Pair p : pairs) {
            uniq.put(p.title + "|" + p.url, p);
        }
        return new ArrayList<>(uniq.values());
    }
}
